import React from 'react';
import { Text, View, Button } from 'react-native';

const About = ({ navigation }) => {
  return (
    <View>
      <Text>HALAMAN ABOUT</Text>
      <Text>Nama : Fahrul </Text>
      <Text>Kelas : B2 </Text>
      <Text>Jurusan : TI </Text>
    </View>
  );
};
export default About;