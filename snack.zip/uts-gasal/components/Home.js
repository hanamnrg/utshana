import React from 'react';
import { Text, View, Button } from 'react-native';

const Home = ({ navigation }) => {
  return (
    <View>
      <Text>HALAMAN HOME</Text>
      <Text>Pilih Menu</Text>
      <Button
        title="ke halaman About"
        onPress={() => navigation.navigate('About')}
      />
    </View>
  );
};
export default Home;
